from rest_framework import serializers

schema_choice = (
    ('employee','employee'),
    ('personalization','personalization'),
)

dbhub = (
    ('MySQL','MySQL'),
    ('MongoDB','MongoDB'),
    ('TIGERGRAPH','TIGERGRAPH'),
)

class createschemaserializer(serializers.Serializer):
    client_name = serializers.CharField(max_length=100)
    schema_type = serializers.ChoiceField(choices=schema_choice)
    db_type = serializers.ChoiceField(choices=dbhub)