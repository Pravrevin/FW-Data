import pyTigerGraph as pyt

def tigergraph_connecter(client_name,tg_conn,schema_type):
    print('Creating Tigergraph schema')
    print(client_name,tg_conn,schema_type)
    conn = pyt.TigerGraphConnection(host=tg_conn[0]['hostname'],graphname=tg_conn[0]['graphname'],
                                    username=tg_conn[0]['username'],password=tg_conn[0]['password'],
                                    restppPort="9000",gsPort=tg_conn[0]['port'],gsqlVersion="",
                                    version="",apiToken=tg_conn[0]['apitoken'],useCert=True,
                                    certPath=None,debug=False,sslPort="443",gcp=False)
    print(conn.gsUrl)
    schema_path = 'C:/work/YouTube Content/Project_Public/alligator/createschema/alligatorBucket/Query/gsql/' + str(
        schema_type) + '/'
    print(schema_path)
    return conn