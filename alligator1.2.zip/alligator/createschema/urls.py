from django.urls import path
from . import views

urlpatterns = [
    path('createschema/',views.createschema.as_view()), #API
    path('',views.home_view,name='home'),
    path('schemadetails/', views.schemadetails, name='schemadetails'),
    path('getschema', views.getschema, name='getschema'),
]
