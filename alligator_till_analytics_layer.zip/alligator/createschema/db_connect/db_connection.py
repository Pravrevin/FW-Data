from createschema.models import MySQLConnect,TigergraphConnect
from .mysqlconnect import mysql_connecter as mysql
from .tigergraphconnect import tigergraph_connecter as tg


def db_conn(client_name,dbtype,dbalias,schema_type):
    if dbtype == 'MySQL':
        mysql_connection = MySQLConnect.objects.filter(dbalias = dbalias).values()
        conn = mysql(client_name,mysql_connection,schema_type)
        return conn
    elif dbtype == 'TIGERGRAPH':
        print('In Tigergraph Connection')
        tg_conn = TigergraphConnect.objects.filter(dbalias=dbalias).values()
        conn = tg(client_name, tg_conn, schema_type)
        return conn


