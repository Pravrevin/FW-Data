from django.urls import path
from . import views

urlpatterns = [
    path('createschema/',views.createschema.as_view()), #API
    path('csvloader/',views.csvloader.as_view()), #API
    path('jsonloader/',views.jsonloader.as_view()), #API
    path('awss3upload/',views.awss3upload.as_view()), #API
    path('datageneratectxn/',views.datageneratectxn.as_view()), #API
    path('',views.home_view,name='home'),
    path('schemadetails/', views.schemadetails, name='schemadetails'),
    path('getschema', views.getschema, name='getschema'),
    path('dataingestion', views.dataingestion, name='dataingestion'),
]
