from django.contrib import admin
from .models import DataSourceBatchIngestion,sftpconnection,s3bucketconnection

admin.site.register(DataSourceBatchIngestion)
admin.site.register(sftpconnection)
admin.site.register(s3bucketconnection)
