from django.db import models

connection_choice = (
    ("s3bucket","s3bucket"),
    ("sftp","sftp")
)

class DataSourceBatchIngestion(models.Model):
    datasourcealias = models.CharField(max_length=100,primary_key=True)
    connectionchoice = models.CharField(max_length=100,choices=connection_choice)

    def __str__(self):
        return self.datasourcealias

class s3bucketconnection(models.Model):
    datasourcealias = models.ForeignKey(DataSourceBatchIngestion,on_delete=models.CASCADE)
    secretkey = models.CharField(max_length=100,primary_key=True)
    accesskey = models.CharField(max_length=100)
    tokenkey = models.CharField(max_length=100,default='',null=True,blank=True)

    def __str__(self):
        return self.datasourcealias

class sftpconnection(models.Model):
    datasourcealias = models.ForeignKey(DataSourceBatchIngestion, on_delete=models.CASCADE)
    hostname = models.CharField(max_length=100, primary_key=True)
    port = models.CharField(max_length=100)
    username = models.CharField(max_length=10)
    password = models.CharField(max_length=100)

    def __str__(self):
        return self.datasourcealias


