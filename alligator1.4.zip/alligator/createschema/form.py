from django import forms

dbtype = [
    ("MySQL","MySQL"),
    ("TIGERGRAPH","TIGERGRAPH"),
]
schematype = [
    ("employee","employee"),
    ("Personalization","Personalization"),
    ("supply Chain Management","supply Chain Management"),
]

class createschemainput(forms.Form):
    ClientName = forms.CharField()
    SchemaType= forms.ChoiceField(choices=schematype)
    DatabaseType = forms.ChoiceField(choices=dbtype)