from django.urls import path
from . import views

urlpatterns = [
    path('createschema/',views.createschema.as_view())
]
