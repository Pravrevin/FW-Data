import logging
from rest_framework.views import APIView
from .serializers import createschemaserializer
from rest_framework.response import Response
from createschema.db_connect.db_connection import db_conn as db
from rest_framework import status
class createschema(APIView):

    def post(self,request):
        serializer = createschemaserializer(data=request.data)
        if serializer.is_valid():
            client_name = serializer.data['client_name']
            schema_type = serializer.data['schema_type']
            db_type = serializer.data['db_type']
            dbType = db(client_name=client_name,dbtype=db_type,dbalias='localhost',schema_type=schema_type)
            print(dbType)
            return Response(serializer.data,status=status.HTTP_200_OK)
        return Response(serializer.errors,status==status.HTTP_400_BAD_REQUEST)









