from django.contrib import admin
from .models import MySQLConnect

admin.site.register(MySQLConnect)
