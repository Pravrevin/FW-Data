import logging
from django.shortcuts import render
from rest_framework.views import APIView
from .serializers import createschemaserializer,csvreaderserializer
from rest_framework.response import Response
from createschema.db_connect.db_connection import db_conn as db
from rest_framework import status
from .form import createschemainput
import requests
import pyspark
from pyspark.sql import SparkSession

class csvloader(APIView):

    def post(self,request):
        csv_path = "D:/work/alligator/createschema/alligatorBucket/data/csv/"
        serializer = csvreaderserializer(data=request.data)
        if serializer.is_valid():
            sourcetype = serializer.data['sourcetype']
            header = serializer.data['header']
            delimiter = serializer.data['delimiter']
            bucketname = serializer.data['bucketname']
            csv_folder = csv_path + bucketname +'/'
            spark = SparkSession.builder.master("local").appName("revin").getOrCreate()
            print(sourcetype, header, delimiter, bucketname, csv_folder)
            df = spark.read.csv(csv_folder)
            print(df.schema)

            return Response(serializer.data,status=status.HTTP_200_OK)
        return Response(serializer.errors,status=status.HTTP_400_BAD_REQUEST)

class createschema(APIView):

    def post(self,request):
        serializer = createschemaserializer(data=request.data)
        if serializer.is_valid():
            client_name = serializer.data['client_name']
            schema_type = serializer.data['schema_type']
            db_type = serializer.data['db_type']
            dbType = db(client_name=client_name,dbtype=db_type,dbalias='localhost',schema_type=schema_type)
            print("this is just to check",dbType)
            return Response(serializer.data,status=status.HTTP_200_OK)
        return Response(serializer.errors,status=status.HTTP_400_BAD_REQUEST)

def home_view(request):
    return render(request,'createschema/home.html')

def schemadetails(request):
    print('Form Redirection to invoke Post API')
    if request.method == 'POST':
        x = createschemainput(request.POST)
        print('schemadetails', x)
        ClientName=x.cleaned_data['ClientName']
        SchemaType=x.cleaned_data['SchemaType']
        DatabaseType=x.cleaned_data['DatabaseType']
        print('schema details = ',ClientName,SchemaType,DatabaseType)
        url = "http://127.0.0.1:8000/createschema/"
        input_data = {
                    "client_name" : ClientName,
                    "schema_type" : SchemaType,
                    "db_type" : DatabaseType
                    }
        x = requests.post(url, data=input_data)
        print(x.status_code)

    return render(request,'createschema/schemadetails.html')

def getschema(request):
    print('getschema Input Form')
    x = createschemainput()
    return render(request, 'createschema/getschema.html',{'form': x})

def dataingestion(request):
    print('Inside Data Ingestion')
    return  render(request,'createschema/dataingestion.html')
