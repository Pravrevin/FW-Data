from django.apps import AppConfig


class CreateschemaConfig(AppConfig):
    name = 'createschema'
