create table employeeDetails(
    employee_id INT PRIMARY KEY,
    employee_name VARCHAR(255),
    employee_address VARCHAR(255),
    employee_dept VARCHAR(255)
);