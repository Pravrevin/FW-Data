import pyTigerGraph as pyt
import os

def tigergraph_connecter(client_name,tg_conn,schema_type):
    print('Creating Tigergraph schema')
    print(client_name,tg_conn,schema_type)
    conn = pyt.TigerGraphConnection(host=tg_conn[0]['hostname'],graphname=tg_conn[0]['graphname'],
                                    username=tg_conn[0]['username'],password=tg_conn[0]['password'],
                                    restppPort="9000",gsPort=tg_conn[0]['port'],gsqlVersion="",
                                    version="",apiToken=tg_conn[0]['apitoken'],useCert=True,
                                    certPath=None,debug=False,sslPort="443",gcp=False)
    print(conn.gsUrl)
    schema_path = 'D:/work/alligator/createschema/alligatorBucket/Query/gsql/' + str(schema_type) + '/'
    print(schema_path)
    sql_file_names = [f for f in os.listdir(schema_path) if f.endswith('.gsql')]
    print(sql_file_names)
    for var in sql_file_names:
        sql_file = schema_path + var
        print(sql_file)
        f = open(sql_file,'r')
        try:
            generateschema = conn.gsql(query=f.read())
            print('Vertex & Edges Created in Tigergraph')
            print(generateschema)
        except Exception as e:
            print(e)
        finally:
            print('Creating Graph for Client')
            graph_path = schema_path + 'personalization_graph.txt'
            f= open(graph_path)
            graphdata = "create graph "+client_name+"_"+schema_type+"("+f.read() +")"
            print(graphdata,type(graphdata))
            generategraph = conn.gsql(graphdata)
            print(generategraph)

    return conn