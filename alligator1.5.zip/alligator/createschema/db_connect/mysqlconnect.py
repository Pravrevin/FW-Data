import mysql.connector
import os

def mysql_connecter(client_name,mysql_connection,schema_type):
    mydb = mysql.connector.connect(
        host=mysql_connection[0]['hostname'],
        user=mysql_connection[0]['username'],
        password=mysql_connection[0]['password']
    )
    schema_path = 'D:/work/alligator/createschema/alligatorBucket/Query/'+str(schema_type)+'/'
    mycursor = mydb.cursor()
    create_db_query = "create database "+client_name +"_"+schema_type+";"
    mycursor.execute(create_db_query)
    db_name = "use " + client_name +"_"+schema_type+";"
    mycursor.execute(db_name)
    sql_file_names = os.listdir(schema_path)
    for var in sql_file_names:
        sql_file = schema_path+var
        with open(sql_file, 'r') as f:
            with mydb.cursor() as cursor:
                cursor.execute(f.read(), multi=True)
                myresult = cursor.fetchall()
                print(myresult)
            mydb.commit()

    return mydb

