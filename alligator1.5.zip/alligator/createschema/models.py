from django.db import models

class MySQLConnect(models.Model):
    dbalias = models.CharField(max_length=100,primary_key=True)
    hostname = models.CharField(max_length=100)
    port = models.CharField(max_length=100)
    username = models.CharField(max_length=100)
    password = models.CharField(max_length=100)

    def __str__(self):
        return self.dbalias

class TigergraphConnect(models.Model):
    dbalias = models.CharField(max_length=100,primary_key=True)
    hostname = models.CharField(max_length=100)
    port = models.CharField(max_length=100)
    username = models.CharField(max_length=100)
    password = models.CharField(max_length=100)
    apitoken = models.CharField(max_length=100,null=True,default='',blank=True)
    graphname = models.CharField(max_length=100,null=True,default='',blank=True)

    def __str__(self):
        return self.dbalias