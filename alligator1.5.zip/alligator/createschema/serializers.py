from rest_framework import serializers

schema_choice = (
    ('employee','employee'),
    ('Personalization','Personalization'),
)

dbhub = (
    ('MySQL','MySQL'),
    ('MongoDB','MongoDB'),
    ('TIGERGRAPH','TIGERGRAPH'),
)

source = (
    ('S3Bucket','S3Bucket'),
    ('GenomeBucket','GenomeBucket'),
    ('SFTP','SFTP'),
)

class createschemaserializer(serializers.Serializer):
    client_name = serializers.CharField(max_length=100)
    schema_type = serializers.ChoiceField(choices=schema_choice)
    db_type = serializers.ChoiceField(choices=dbhub)

class csvreaderserializer(serializers.Serializer):
    sourcetype = serializers.ChoiceField(choices=source)
    bucketname = serializers.CharField(max_length=100,allow_null=True,required=False)
    header = serializers.BooleanField(default=True,allow_null=True)
    delimiter = serializers.CharField(default=',',allow_null=True,required=False)