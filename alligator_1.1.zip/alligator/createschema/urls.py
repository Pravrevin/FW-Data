from django.urls import path
from . import views

urlpatterns = [
    path('createschema/',views.createschema.as_view()),
    path('',views.home_view),
    path('createschema/', views.home_view, name='genome-cs'),
    path('apicall/', views.api_call, name='api-call'),
]
