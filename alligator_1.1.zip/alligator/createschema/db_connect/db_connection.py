from createschema.models import MySQLConnect
from .mysqlconnect import mysql_connecter as mysql
def db_conn(client_name,dbtype,dbalias,schema_type):
    if dbtype == 'MySQL':
        mysql_connection = MySQLConnect.objects.filter(dbalias = dbalias).values()
        conn = mysql(client_name,mysql_connection,schema_type)
        return conn

