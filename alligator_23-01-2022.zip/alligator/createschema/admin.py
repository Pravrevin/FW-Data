from django.contrib import admin
from .models import MySQLConnect,TigergraphConnect

admin.site.register(MySQLConnect)
admin.site.register(TigergraphConnect)