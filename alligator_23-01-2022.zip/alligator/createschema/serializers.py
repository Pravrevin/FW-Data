from rest_framework import serializers

schema_choice = (
    ('employee','employee'),
    ('Personalization','Personalization'),
)

dbhub = (
    ('MySQL','MySQL'),
    ('MongoDB','MongoDB'),
    ('TIGERGRAPH','TIGERGRAPH'),
)

source = (
    ('S3Bucket','S3Bucket'),
    ('GenomeBucket','GenomeBucket'),
    ('SFTP','SFTP'),
)

filesource = (
    ('csv','csv'),
    ('json','json'),
    ('xlsx','xlsx'),
)

class createschemaserializer(serializers.Serializer):
    client_name = serializers.CharField(max_length=100)
    schema_type = serializers.ChoiceField(choices=schema_choice)
    db_type = serializers.ChoiceField(choices=dbhub)

class csvreaderserializer(serializers.Serializer):
    sourcetype = serializers.ChoiceField(choices=source)
    bucketname = serializers.CharField(max_length=100,allow_null=True,required=False)
    header = serializers.BooleanField(default=True,allow_null=True)
    delimiter = serializers.CharField(default=',',allow_null=True,required=False)

class jsonreaderserializer(serializers.Serializer):
    sourcetype = serializers.ChoiceField(choices=source)
    bucketname = serializers.CharField(max_length=100,allow_null=True,required=False)

class awss3bucketserializer(serializers.Serializer):
    sourcetype = serializers.ChoiceField(choices=source)
    filetype = serializers.ChoiceField(choices=filesource)
    sourcebucketname = serializers.CharField(max_length=100, allow_null=True, required=False)
    awsbucketname = serializers.CharField(max_length=100, allow_null=True, required=False)

class customertxnserializer(serializers.Serializer):
    transactionidstartrange = serializers.IntegerField(allow_null=True,required=False)
    transactionidendrange = serializers.IntegerField( allow_null=True, required=False)
    storeid = serializers.CharField(max_length=10,allow_null=True,required=False)
    storename = serializers.CharField(max_length=100, allow_null=True, required=False)
    profilestartid = serializers.IntegerField(allow_null=True, required=False)
    profileendid = serializers.IntegerField( allow_null=True, required=False)
    productstartid = serializers.IntegerField(allow_null=True, required=False)
    productendid = serializers.IntegerField( allow_null=True, required=False)
    datestartrange = serializers.DateField(allow_null=True, required=False)
    dateendrange = serializers.DateField(allow_null=True, required=False)
    quantitystartrange = serializers.IntegerField(allow_null=True, required=False)
    quantityendrange = serializers.IntegerField( allow_null=True, required=False)