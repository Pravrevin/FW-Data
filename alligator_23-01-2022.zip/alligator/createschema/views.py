import logging
import random
from datetime import datetime

import pandas as pd
from django.shortcuts import render
from rest_framework.views import APIView
from .serializers import createschemaserializer,csvreaderserializer,jsonreaderserializer,awss3bucketserializer,customertxnserializer
from rest_framework.response import Response
from createschema.db_connect.db_connection import db_conn as db
from rest_framework import status
from .form import createschemainput
import requests
import pyspark
from pyspark.sql import SparkSession
import glob
import os
import boto3

class datageneratectxn(APIView):

    def post(self,request):
        csv_path = "D:/work/alligator/createschema/alligatorBucket/data/csv/"
        serializer = customertxnserializer(data=request.data)
        if serializer.is_valid():
            transactionidstartrange = serializer.data['transactionidstartrange']
            transactionidendrange = serializer.data['transactionidendrange']
            storeid = serializer.data['storeid']
            storename = serializer.data['storename']
            profilestartid = serializer.data['profilestartid']
            profileendid = serializer.data['profileendid']
            productstartid = serializer.data['productstartid']
            productendid = serializer.data['productendid']
            datestartrange = serializer.data['datestartrange']
            dateendrange = serializer.data['dateendrange']
            quantitystartrange = serializer.data['quantitystartrange']
            quantityendrange = serializer.data['quantityendrange']

            print(type(dateendrange),type(datestartrange))
            datestartrange_ = datetime.strptime(datestartrange, '%Y-%m-%d')
            dateendrange_ = datetime.strptime(dateendrange, '%Y-%m-%d')

            transaction_id = random.sample(range(transactionidstartrange,transactionidendrange),400)
            store_id = list(storeid) *400
            store_name = [storename] *400
            profile_id = [random.randrange(profilestartid,profileendid,1) for i in range(400)]
            product_id = [random.randrange(productstartid,productendid,1) for j in range(400)]
            order_date = []
            week_id = []
            for var in range(400):
                random_date = datestartrange_ + (dateendrange_ - datestartrange_) * random.random()
                week_id_number = random_date.isocalendar()[1]
                order_date.append(random_date)
                week_id.append(week_id_number)

            order_qty = [random.randrange(quantitystartrange,quantityendrange,1) for i in range(400)]
            #print(transaction_id,store_id,store_name,profile_id,product_id,order_qty)
            final_txn_data = {
                'transaction_id' : transaction_id,
                'store_id' :store_id,
                'store_name':store_name,
                'profile_id':profile_id,
                'product_id':product_id,
                'order_date':order_date,
                'week_id': week_id,
                'order_qty':order_qty
            }
            print(final_txn_data)
            final_df = pd.DataFrame(final_txn_data)
            final_df.to_csv('customer_transaction_data.csv')


            return Response(serializer.data,status=status.HTTP_200_OK)
        return Response(serializer.errors,status=status.HTTP_400_BAD_REQUEST)
class awss3upload(APIView):

    def post(self,request):
        s3_resource = boto3.client(
            's3',
            aws_access_key_id='AKIAX5VSTI6XQBOFP45F',
            aws_secret_access_key='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'
        )
        serializer = awss3bucketserializer(data=request.data)
        if serializer.is_valid():
            sourcetype = serializer.data['sourcetype']
            sourcebucketname = serializer.data['sourcebucketname']
            awsbucketname = serializer.data['awsbucketname']
            if sourcetype == 'GenomeBucket':
                print('Inside Genome Bucket')
                data_path = "D:/work/alligator/createschema/alligatorBucket/data/"
                filetype = serializer.data['filetype']
                if filetype == 'csv':
                    print('Inside csv data folder')
                    filespath = data_path+"csv/" + sourcebucketname
                    filenames = glob.glob(data_path + "csv/" + sourcebucketname + "/*.csv")
                    print(filespath)
                    for file in filenames:
                        object_name = os.path.basename(file)
                        s3_resource.upload_file(file, awsbucketname, object_name)

                elif filetype == 'json':
                    print('Inside json data folder')
                    filespath = data_path + "json/" + sourcebucketname
                    filenames = glob.glob(data_path + "json/" + sourcebucketname + "/*.json")
                    print(filespath)
                    for file in filenames:
                        object_name = os.path.basename(file)
                        s3_resource.upload_file(file, awsbucketname, object_name)

                return Response(serializer.data,status=status.HTTP_200_OK)
        return Response(serializer.errors,status=status.HTTP_400_BAD_REQUEST)
class jsonloader(APIView):

    def post(self,request):
        json_path = "D:/work/alligator/createschema/alligatorBucket/data/json/"
        serializer = jsonreaderserializer(data=request.data)
        if serializer.is_valid():
            sourcetype = serializer.data['sourcetype']
            bucketname = serializer.data['bucketname']
            json_folder = json_path + bucketname +'/'
            if sourcetype == 'GenomeBucket':
                print('Inside Genome Bucket')
                spark = SparkSession.builder.master("local").appName("revin").getOrCreate()
                filename = glob.glob(json_folder+"*.json")
                print(sourcetype,bucketname, json_folder)
                print(filename)
                df = spark.read.json(filename)
                print(df.schema)
                return Response(serializer.data,status=status.HTTP_200_OK)
        return Response(serializer.errors,status=status.HTTP_400_BAD_REQUEST)

class csvloader(APIView):

    def post(self,request):
        csv_path = "D:/work/alligator/createschema/alligatorBucket/data/csv/"
        serializer = csvreaderserializer(data=request.data)
        if serializer.is_valid():
            sourcetype = serializer.data['sourcetype']
            header = serializer.data['header']
            delimiter = serializer.data['delimiter']
            bucketname = serializer.data['bucketname']
            csv_folder = csv_path + bucketname +'/'
            if sourcetype == 'GenomeBucket':
                print('Inside Genome Bucket')
                spark = SparkSession.builder.master("local").appName("revin").getOrCreate()
                filename = glob.glob(csv_folder+"*.csv")
                print(sourcetype, header, delimiter, bucketname, csv_folder)
                print(filename)
                df = spark.read.csv(filename,sep=delimiter,header=header)
                print(df.schema)

                return Response(serializer.data,status=status.HTTP_200_OK)
        return Response(serializer.errors,status=status.HTTP_400_BAD_REQUEST)

class createschema(APIView):

    def post(self,request):
        serializer = createschemaserializer(data=request.data)
        if serializer.is_valid():
            client_name = serializer.data['client_name']
            schema_type = serializer.data['schema_type']
            db_type = serializer.data['db_type']
            dbType = db(client_name=client_name,dbtype=db_type,dbalias='localhost',schema_type=schema_type)
            print("this is just to check",dbType)
            return Response(serializer.data,status=status.HTTP_200_OK)
        return Response(serializer.errors,status=status.HTTP_400_BAD_REQUEST)

def home_view(request):
    return render(request,'createschema/home.html')

def schemadetails(request):
    print('Form Redirection to invoke Post API')
    if request.method == 'POST':
        x = createschemainput(request.POST)
        print('schemadetails', x)
        ClientName=x.cleaned_data['ClientName']
        SchemaType=x.cleaned_data['SchemaType']
        DatabaseType=x.cleaned_data['DatabaseType']
        print('schema details = ',ClientName,SchemaType,DatabaseType)
        url = "http://127.0.0.1:8000/createschema/"
        input_data = {
                    "client_name" : ClientName,
                    "schema_type" : SchemaType,
                    "db_type" : DatabaseType
                    }
        x = requests.post(url, data=input_data)
        print(x.status_code)

    return render(request,'createschema/schemadetails.html')

def getschema(request):
    print('getschema Input Form')
    x = createschemainput()
    return render(request, 'createschema/getschema.html',{'form': x})

def dataingestion(request):
    print('Inside Data Ingestion')
    return  render(request,'createschema/dataingestion.html')
